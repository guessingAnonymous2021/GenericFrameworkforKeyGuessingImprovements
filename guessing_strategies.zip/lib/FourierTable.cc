#include "FourierTable.hpp"
uint64_t FourierTableAux::MyPopcount(uint64_t x) { return std::popcount(x); }
